import 'package:flutter/material.dart';
import 'package:windou/windou/core/constants/color_palatte.dart';
import 'package:windou/windou/core/helper/image_helper.dart';
import 'package:windou/windou/core/helper/text_styles.dart';
import 'package:windou/windou/presentations/screens/Home/navigation_home.dart';
import 'package:windou/windou/presentations/widgets/button_widget.dart';

import '../../../core/helper/assets_helper.dart';

class ReceiveCertificateScreen extends StatefulWidget {
  const ReceiveCertificateScreen({super.key});
  static final String routeName = 'ReceiveCertificate_screen';

  @override
  State<ReceiveCertificateScreen> createState() =>
      _ReceiveCertificateCreenState();
}

class _ReceiveCertificateCreenState extends State<ReceiveCertificateScreen> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Scaffold(
        backgroundColor: Colors.white,
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              margin: EdgeInsets.symmetric(horizontal: size.width / 16),
              child: Text(
                "Chúc mừng bạn đã\nnhận được chứng chỉ",
                style: TextStyles.h1.bold,
              ),
            ),
            Container(
              height: size.width * 7 / 8,
              width: size.width * 7 / 8,
              child: Stack(
                children: [
                  Positioned(
                    top: 0,
                    child: ImageHelper.loadFromAsset(AssetHelper.certification,
                        height: size.width * 7 / 8, width: size.width * 7 / 8),
                  ),
                  Positioned(
                    bottom: 100,
                    left: 0,
                    child: Column(
                      children: [
                        Container(
                          width: size.width * 7 / 8,
                          padding: EdgeInsets.symmetric(horizontal: 20),
                          alignment: Alignment.centerLeft,
                          child: Text(
                            "Anh Minh",
                            style: TextStyles.h2.bold
                                .copyWith(color: Colors.white),
                          ),
                        ),
                        SizedBox(
                          height: 15,
                        ),
                        Container(
                          width: size.width * 7 / 8,
                          padding: EdgeInsets.symmetric(horizontal: 20),
                          alignment: Alignment.centerLeft,
                          child: Text(
                            "Đã bù đắp 12 tấn do đóng góp\nvào tín chỉ carbon",
                            style: TextStyles.h5.copyWith(color: Colors.white),
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.symmetric(horizontal: size.width / 16),
              child: ButtonWidget(
                  label: "Trang chủ",
                  color: ColorPalette.primaryColor,
                  textColor: Colors.white,
                  onTap: () {
                    Navigator.of(context).pushNamedAndRemoveUntil(
                        NavigationHome.routeName, (route) => false);
                  }),
            )
          ],
        ));
  }
}
