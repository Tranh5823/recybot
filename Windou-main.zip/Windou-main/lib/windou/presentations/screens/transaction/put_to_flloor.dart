import 'package:flutter/material.dart';
import 'package:windou/windou/core/constants/color_palatte.dart';
import 'package:windou/windou/core/helper/image_helper.dart';
import 'package:windou/windou/core/helper/text_styles.dart';
import 'package:windou/windou/presentations/widgets/button_widget.dart';

import '../../../core/helper/assets_helper.dart';
import '../Home/navigation_home.dart';

class PutToFloorScreen extends StatefulWidget {
  const PutToFloorScreen({super.key});
  static final String routeName = 'PutToFloor_screen';

  @override
  State<PutToFloorScreen> createState() => _PutToFloorCreenState();
}

class _PutToFloorCreenState extends State<PutToFloorScreen> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Scaffold(
        backgroundColor: Colors.white,
        body: Container(
            color: ColorPalette.primaryColor,
            width: size.width,
            padding: EdgeInsets.symmetric(horizontal: 50),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ImageHelper.loadFromAsset(AssetHelper.successIcon,
                    height: 120, width: 120),
                    SizedBox(height: 50),
                    Text("Xác nhận lên sàn", style: TextStyles.h1.bold.whiteTextColor.copyWith(fontSize: 36),),
                    SizedBox(height: 20),
                    Text("Cảm ơn bạn đã đóng góp môi trường xanh!", textAlign: TextAlign.center, style: TextStyles.h5.whiteTextColor,),
                    SizedBox(height: 50),
                      Container(
              margin: EdgeInsets.symmetric(horizontal: size.width / 16),
              child: ButtonWidget(
                  label: "Trang chủ",
                  color: ColorPalette.white,
                  textColor: Colors.black,
                  onTap: () {
                    Navigator.of(context).pushNamedAndRemoveUntil(
                        NavigationHome.routeName, (route) => false);
                  }),
            )
          
              ],
            )));
  }
}
