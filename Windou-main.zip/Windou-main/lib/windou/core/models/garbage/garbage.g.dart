// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'garbage.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GarbageModelImpl _$$GarbageModelImplFromJson(Map<String, dynamic> json) =>
    _$GarbageModelImpl(
      id: json['id'] as String,
      name: json['name'] as String,
      imageLink: json['imageLink'] as String,
      price: json['price'] as String,
    );

Map<String, dynamic> _$$GarbageModelImplToJson(_$GarbageModelImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'imageLink': instance.imageLink,
      'price': instance.price,
    };
